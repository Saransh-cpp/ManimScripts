from manim import *
import numpy as np
import math
import random


class CyclotronIntro(Scene):
    config.background_color = YELLOW_C

    def construct(self):
        def archimedean_spiral(t):
            r = 0.1 + 0.1 * t
            return np.array([r * np.cos(t), r * np.sin(t), 0])

        # self.add(NumberPlane())
        self.add_sound(
            "Soft Inspirational Background Music for Videos & Presentation.mp3"
        )

        myTemplate = TexTemplate()
        myTemplate.add_to_preamble(r"\usepackage{circuitikz}")
        myTemplate.add_to_preamble(r"\usepackage{tikz}")
        myTemplate.add_to_preamble(r"\usepackage{siunitx}")

        Bat = (
            Tex(
                r"""
            \begin{circuitikz}
            \draw
            (0,3) to[sV] (0,0)
            ;
            \end{circuitikz}
            """,
                stroke_width=2,
                fill_opacity=0,
                tex_template=myTemplate,
            )
            .set_color(BLACK)
            .rotate(PI / 2)
            .move_to(2.5 * UP)
        )

        w1 = (
            Line()
            .rotate(PI / 2)
            .scale(1.18)
            .move_to(2.12 * RIGHT + 1.33 * UP)
            .set_color(BLACK)
        )
        w2 = (
            Line()
            .rotate(PI / 2)
            .scale(1.18)
            .move_to(2.12 * LEFT + 1.33 * UP)
            .set_color(BLACK)
        )

        d1_arc = (
            Arc(angle=PI, radius=2)
            .rotate(PI / 2)
            .move_to(1.5 * LEFT + DOWN)
            .set_color(BLACK)
        )
        d2_arc = (
            Arc(angle=PI, radius=2)
            .rotate(3 * PI / 2)
            .move_to(1.5 * RIGHT + DOWN)
            .set_color(BLACK)
        )
        d1_l = (
            Line(length=8)
            .scale(2)
            .rotate(PI / 2)
            .move_to(0.5 * LEFT + DOWN)
            .set_color(BLACK)
        )
        d2_l = (
            Line(length=8)
            .scale(2)
            .rotate(PI / 2)
            .move_to(0.5 * RIGHT + DOWN)
            .set_color(BLACK)
        )

        t1 = (
            Tex(
                r"A cyclotron is a device used to\\accelerate charged particles to\\induce high-energy systems used in\\real-world nuclear physics to\\bombard nuclei for the study of\\nuclear reactions."
            )
            .set_color(BLACK)
            .move_to(4.7 * RIGHT)
            .scale(0.6)
        )

        t2 = (
            Tex(
                r"The cyclotron was invented in the\\early 1930s by E.O. Lawrence\\at the University of\\California, Berkeley."
            )
            .set_color(BLACK)
            .move_to(4.7 * LEFT)
            .scale(0.6)
        )

        self.play(Write(d1_arc), Write(d2_arc), Write(d1_l), Write(d2_l))
        self.play(Write(Bat), Write(w1), Write(w2))
        self.play(FadeIn(t1))
        self.wait(4)
        self.play(FadeIn(t2))
        self.wait(2)
        self.play(FadeOut(t1), FadeOut(t2))

        d_list = []
        c_list = []
        for i in range(-2, 3):
            for j in range(-3, 2):
                d = Dot().move_to(i * LEFT + j * UP).set_color(RED)
                c = Circle(radius=0.15).move_to(i * LEFT + j * UP)
                d_list.append(d)
                c_list.append(c)
                self.play(Write(c, run_time=0.2), Write(d, run_time=0.2))

        t3 = (
            Tex(
                r"Two hollow D-shaped sheet metal\\electrodes known as the dees inside\\vaccum chamber are located between\\the poles which apply a static\\magnetic field B perpendicular\\to the electrode plane"
            )
            .set_color(BLACK)
            .move_to(4.65 * RIGHT)
            .scale(0.6)
        )

        self.wait()
        self.play(FadeIn(t3))
        self.wait(3)

        for i, j in zip(d_list, c_list):
            self.play(FadeOut(i, run_time=0.1), FadeOut(j, run_time=0.1))

        self.play(FadeOut(t3))

        t4 = (
            Tex(
                r"An alternating voltage of several\\thousand volts is applied between\\the dees. The voltage creates an\\oscillating electric field in the gap\\between the dees, accelerating\\the particles"
            )
            .set_color(BLACK)
            .move_to(4.7 * LEFT)
            .scale(0.6)
        )

        self.play(FadeIn(t4))
        self.wait(3)

        a_list = []
        for i in range(-2, 3):
            for j in range(-3, 2):
                a = Arrow().set_color(RED).scale(0.6).move_to(i * LEFT + j * UP)
                a_list.append(a)
                self.play(Write(a, run_time=0.2))

        for a in a_list:
            self.play(FadeOut(a, run_time=0.1))

        self.play(FadeOut(t4))

        a_list = []
        for i in range(-2, 3):
            for j in range(-3, 2):
                a = (
                    Arrow()
                    .set_color(RED)
                    .scale(0.6)
                    .rotate(PI)
                    .move_to(i * LEFT + j * UP)
                )
                a_list.append(a)
                self.play(Write(a, run_time=0.2))

        for a in a_list:
            self.play(FadeOut(a, run_time=0.1))

        t5 = (
            Tex(
                r"The frequency of the voltage\\is set so that particles make one\\circuit during a single cycle of the\\voltage. To achieve this condition,\\the frequency must be set to\\particle's cyclotron frequency"
            )
            .set_color(BLACK)
            .move_to(4.65 * RIGHT)
            .scale(0.6)
        )

        self.play(FadeIn(t5))
        self.wait(4)

        a_s = ParametricFunction(
            archimedean_spiral,
            color=BLACK,
            t_range=np.array([0, 12 * PI]),
        )
        a_s.scale(0.5).move_to(DOWN)
        self.play(Write(a_s, run_time=3))

        dot = Dot().set_color(RED).move_to(DOWN)
        self.play(Write(dot))
        self.wait()
        self.play(MoveAlongPath(dot, a_s), run_time=5, rate_func=linear)
        self.wait(3)
        self.play(
            FadeOut(t5),
            FadeOut(dot),
            FadeOut(a_s),
            FadeOut(Bat),
            FadeOut(w1),
            FadeOut(w2),
            FadeOut(d1_arc),
            FadeOut(d1_l),
            FadeOut(d2_arc),
            FadeOut(d2_l),
        )

        nt1 = Tex(
            r"We now attempt to illustrate certain relationship\\between different quantities like velocity, charge,\\and magnetic field which can be ascertained by\\the following process"
        ).set_color(BLACK)
        nt2 = (
            Tex(
                r"Firstly, the centripetal force required to keep the\\particle in its circular motion is given by -"
            )
            .set_color(BLACK)
            .move_to(2.5 * UP)
        )

        self.play(FadeIn(nt1))
        self.wait(5)
        self.play(ReplacementTransform(nt1, nt2))
        self.wait(3)

        nt3 = MathTex(r"F_{c} = m * \frac{v^{2}}{r}").set_color(BLACK)

        nt4 = (
            Tex("m is the mass of the charged particle")
            .set_color(BLACK)
            .move_to(1.5 * LEFT + 1.5 * DOWN)
            .scale(0.75)
        )
        nt5 = (
            Tex("v is the velocity")
            .set_color(BLACK)
            .move_to(3.2 * LEFT + 2 * DOWN)
            .scale(0.75)
        )
        nt6 = (
            Tex("r is the radius")
            .set_color(BLACK)
            .move_to(3.32 * LEFT + 2.5 * DOWN)
            .scale(0.75)
        )

        self.play(Write(nt3))
        self.play(FadeIn(nt4))
        self.play(FadeIn(nt5))
        self.play(FadeIn(nt6))

        nt7 = (
            Tex(
                r"Now, the Lorentz force expression on the\\magnetic field B is given by"
            )
            .set_color(BLACK)
            .move_to(2.5 * UP)
        )

        self.play(ReplacementTransform(nt2, nt7))
        self.wait(3)

        nt8 = MathTex(r"F_{b} = q * v * B").set_color(BLACK)

        nt9 = (
            Tex("q is the charge on the particle")
            .set_color(BLACK)
            .move_to(2.15 * LEFT + 1.5 * DOWN)
            .scale(0.75)
        )
        nt10 = (
            Tex("B is the magnetic field strength")
            .set_color(BLACK)
            .move_to(2.05 * LEFT + 2 * DOWN)
            .scale(0.75)
        )
        nt11 = (
            Tex("v is the velocity")
            .set_color(BLACK)
            .move_to(3.32 * LEFT + 2.5 * DOWN)
            .scale(0.75)
        )

        self.play(ReplacementTransform(nt3, nt8))
        self.play(ReplacementTransform(nt4, nt9))
        self.play(ReplacementTransform(nt5, nt10))
        self.play(ReplacementTransform(nt6, nt11))
        self.wait(2)
        self.play(
            FadeOut(nt9),
            FadeOut(nt10),
            FadeOut(nt11),
        )

        nt12 = (
            Tex("Upon equating these equations, we get -")
            .move_to(2.5 * UP)
            .set_color(BLACK)
        )
        nt13 = MathTex(r"m * \frac{v^{2}}{r} = q * v * B").set_color(BLACK)

        self.play(ReplacementTransform(nt7, nt12))
        self.play(ReplacementTransform(nt8, nt13))

        self.wait(2)

        nt14 = MathTex(r"v = \frac{q * B * r}{m}").set_color(BLACK)

        self.play(ReplacementTransform(nt13, nt14))

        self.wait(2)

        nt15 = (
            Tex(
                r"We also obtain the expression for energy output\\which is be given by -"
            )
            .move_to(2.5 * UP)
            .set_color(BLACK)
        )
        nt16 = MathTex(r"E = \frac{1}{2} * m * v^{2}").set_color(BLACK)
        nt17 = MathTex(r"E = \frac{(q * B * r)^{2}}{2m}").set_color(BLACK)

        self.play(ReplacementTransform(nt12, nt15))
        self.wait()
        self.play(ReplacementTransform(nt14, nt16))
        self.wait(2)
        self.play(ReplacementTransform(nt16, nt17))
        self.wait()

        nt18 = (
            Tex(r"Also, the Time Period of a given revolution\\can be given by -")
            .set_color(BLACK)
            .move_to(2.5 * UP)
        )
        nt19 = MathTex(r"T = \frac{Distance}{Time}").set_color(BLACK)
        nt20 = MathTex(r"T = \frac{2 * \pi * r}{v}").set_color(BLACK)
        nt21 = MathTex(r"T = \frac{2 * \pi * m}{q * B}").set_color(BLACK)
        nt22 = MathTex(r"f = \frac{q * B}{2 * \pi * m}").set_color(BLACK)

        self.play(ReplacementTransform(nt15, nt18))
        self.wait()
        self.play(ReplacementTransform(nt17, nt19))
        self.wait(2)
        self.play(ReplacementTransform(nt19, nt20))
        self.wait(2)
        self.play(ReplacementTransform(nt20, nt21))
        self.wait(4)

        nt23 = (
            Tex("Finally, the frequency can be obtained as -")
            .move_to(2.5 * UP)
            .set_color(BLACK)
        )

        self.play(ReplacementTransform(nt18, nt23))
        self.wait()
        self.play(ReplacementTransform(nt21, nt22))
        self.wait(2)

        nt24 = (
            Tex(r"Let us now move to some hands-on experiment!")
            .set_color(BLACK)
            .scale(1.2)
        )

        self.play(ReplacementTransform(nt23, nt24), FadeOut(nt22))
        self.wait(2)


# class Derivation(Scene):
#     config.background_color = YELLOW_C

#     def construct(self):

#         self.add(NumberPlane())
#         nt1 = Tex(
#             r"We now attempt to illustrate certain relationship\\between different quantities like velocity, charge,\\and magnetic field which can be ascertained by\\the following process"
#         ).set_color(BLACK)
#         nt2 = (
#             Tex(
#                 r"Firstly, the centripetal force required to keep the\\particle in its circular motion is given by -"
#             )
#             .set_color(BLACK)
#             .move_to(2.5 * UP)
#         )

#         self.play(FadeIn(nt1))
#         self.wait(5)
#         self.play(ReplacementTransform(nt1, nt2))
#         self.wait(3)

#         nt3 = MathTex(r"F_{c} = m * \frac{v^{2}}{r}").set_color(BLACK)

#         nt4 = (
#             Tex("m is the mass of the charged particle")
#             .set_color(BLACK)
#             .move_to(1.5 * LEFT + 1.5 * DOWN)
#             .scale(0.75)
#         )
#         nt5 = (
#             Tex("v is the velocity")
#             .set_color(BLACK)
#             .move_to(3.2 * LEFT + 2 * DOWN)
#             .scale(0.75)
#         )
#         nt6 = (
#             Tex("r is the radius")
#             .set_color(BLACK)
#             .move_to(3.32 * LEFT + 2.5 * DOWN)
#             .scale(0.75)
#         )

#         self.play(Write(nt3))
#         self.play(FadeIn(nt4))
#         self.play(FadeIn(nt5))
#         self.play(FadeIn(nt6))

#         nt7 = (
#             Tex(
#                 r"Now, the Lorentz force expression on the\\magnetic field B is given by"
#             )
#             .set_color(BLACK)
#             .move_to(2.5 * UP)
#         )

#         self.play(ReplacementTransform(nt2, nt7))
#         self.wait(3)

#         nt8 = MathTex(r"F_{b} = q * v * B").set_color(BLACK)

#         nt9 = (
#             Tex("q is the charge on the particle")
#             .set_color(BLACK)
#             .move_to(2.15 * LEFT + 1.5 * DOWN)
#             .scale(0.75)
#         )
#         nt10 = (
#             Tex("B is the magnetic field strength")
#             .set_color(BLACK)
#             .move_to(2.05 * LEFT + 2 * DOWN)
#             .scale(0.75)
#         )
#         nt11 = (
#             Tex("v is the velocity")
#             .set_color(BLACK)
#             .move_to(3.32 * LEFT + 2.5 * DOWN)
#             .scale(0.75)
#         )

#         self.play(ReplacementTransform(nt3, nt8))
#         self.play(ReplacementTransform(nt4, nt9))
#         self.play(ReplacementTransform(nt5, nt10))
#         self.play(ReplacementTransform(nt6, nt11))
#         self.wait(2)
#         self.play(
#             FadeOut(nt9),
#             FadeOut(nt10),
#             FadeOut(nt11),
#         )

#         nt12 = (
#             Tex("Upon equating these equations, we get -")
#             .move_to(2.5 * UP)
#             .set_color(BLACK)
#         )
#         nt13 = MathTex(r"m * \frac{v^{2}}{r} = q * v * B").set_color(BLACK)

#         self.play(ReplacementTransform(nt7, nt12))
#         self.play(ReplacementTransform(nt8, nt13))

#         self.wait(2)

#         nt14 = MathTex(r"v = \frac{q * B * r}{m}").set_color(BLACK)

#         self.play(ReplacementTransform(nt13, nt14))

#         self.wait(2)

#         nt15 = (
#             Tex(
#                 r"We also obtain the expression for energy output\\which is be given by -"
#             )
#             .move_to(2.5 * UP)
#             .set_color(BLACK)
#         )
#         nt16 = MathTex(r"E = \frac{1}{2} * m * v^{2}").set_color(BLACK)
#         nt17 = MathTex(r"E = \frac{(q * B * r)^{2}}{2m}").set_color(BLACK)

#         self.play(ReplacementTransform(nt12, nt15))
#         self.wait()
#         self.play(ReplacementTransform(nt14, nt16))
#         self.wait(2)
#         self.play(ReplacementTransform(nt16, nt17))
#         self.wait()

#         nt18 = Tex(r"Also, the Time Period of a given revolution\\can be given by -").set_color(BLACK).move_to(2.5*UP)
#         nt19 = MathTex(r"T = \frac{Distance}{Time}").set_color(BLACK)
#         nt20 = MathTex(r"T = \frac{2 * \pi * r}{v}").set_color(BLACK)
#         nt21 = MathTex(r"T = \frac{2 * \pi * m}{q * B}").set_color(BLACK)
#         nt22 = MathTex(r"f = \frac{q * B}{2 * \pi * m}").set_color(BLACK)

#         self.play(ReplacementTransform(nt15, nt18))
#         self.wait()
#         self.play(ReplacementTransform(nt17, nt19))
#         self.wait(2)
#         self.play(ReplacementTransform(nt19, nt20))
#         self.wait(2)
#         self.play(ReplacementTransform(nt20, nt21))
#         self.wait(4)

#         nt23 = Tex("Finally, the frequency can be obtained as -").move_to(2.5*UP).set_color(BLACK)

#         self.play(ReplacementTransform(nt18, nt23))
#         self.wait()
#         self.play(ReplacementTransform(nt21, nt22))
#         self.wait(2)

#         nt24 = Tex(r"Let us now move to some hands-on experiment!").set_color(BLACK).scale(1.2)

#         self.play(
#             ReplacementTransform(nt23, nt24),
#             FadeOut(nt22)
#         )
#         self.wait(2)


class ExperimentFrequency(Scene):
    config.background_color = YELLOW_C

    def construct(self):
        name = input("Enter your name\n")
        print("===============================================================")
        initial_mass, power_mass = input(
            "Please enter mass of the particle in the following format\nM P where mass = M*10^P Kg\n"
        ).split(" ")
        print("===============================================================")
        mass = float(initial_mass) * 10 ** float(power_mass)
        print("m = " + initial_mass + " * 10^" + power_mass)
        print("===============================================================")
        initial_charge, power_charge = input(
            "Please enter charge of the particle in the following format\nM P where charge = M*10^P C\n"
        ).split(" ")
        print("===============================================================")
        print("q = " + initial_charge + " * 10^" + power_charge)
        print("===============================================================")
        charge = float(initial_charge) * 10 ** float(power_charge)
        initial_b, power_b = input(
            "Please enter Magnetic Field in the following format\nM P where B = M*10^P T\n"
        ).split(" ")
        print("===============================================================")
        print("B = " + initial_b + " * 10^" + power_b)
        print("===============================================================")
        b_field = float(initial_b) * 10 ** float(power_b)
        welcome = Tex(
            r"Welcome " + name + r"!\\Let us begin with some hands-on experiments"
        ).set_color(BLACK)

        freq = (charge * b_field) / (2 * PI * mass)
        freq_with_err = round(random.uniform(freq * 0.9, freq * 1.1), 2)

        self.play(Write(welcome))
        self.wait(3)
        self.play(FadeOut(welcome))

        f = Tex("Calculating frequency").set_color(BLACK).scale(1.5)
        f1 = MathTex(r"f = \frac{q * B}{2 * \pi * m}").set_color(BLACK).move_to(2 * UP)
        f2 = Tex("The experimental value = " + str(freq_with_err) + r" 1/s").set_color(BLACK)

        self.play(Write(f))
        self.wait(3)
        self.play(ReplacementTransform(f, f1))
        self.wait(2)
        self.play(Write(f2))


class ExperimentVelocityOrRadius(Scene):
    config.background_color = YELLOW_C

    def construct(self):

        choice = input("Choose one (type '1' or '2') -\n1. Calculate velocity\n2. Calculate radius\n")
        name = input("Enter your name\n")

        welcome = Tex(
            r"Welcome " + name + r"!\\Let us begin with some hands-on experiments"
        ).set_color(BLACK)


        print("===============================================================")
        initial_mass, power_mass = input(
            "Please enter mass of the particle in the following format\nM P where mass = M*10^P Kg\n"
        ).split(" ")
        print("===============================================================")
        mass = float(initial_mass) * 10 ** float(power_mass)
        print("m = " + initial_mass + " * 10^" + power_mass)
        print("===============================================================")
        initial_charge, power_charge = input(
            "Please enter charge of the particle in the following format\nM P where charge = M*10^P C\n"
        ).split(" ")
        print("===============================================================")
        print("q = " + initial_charge + " * 10^" + power_charge)
        print("===============================================================")
        charge = float(initial_charge) * 10 ** float(power_charge)
        initial_b, power_b = input(
            "Please enter Magnetic Field in the following format\nM P where B = M*10^P T\n"
        ).split(" ")
        print("===============================================================")
        print("B = " + initial_b + " * 10^" + power_b)
        print("===============================================================")
        b_field = float(initial_b) * 10 ** float(power_b)
        if choice == "1":
            initial_r, power_r = input(
                "Please enter radius in the following format\nM P where r = M*10^P m\n"
            ).split(" ")
            print("===============================================================")
            print("R = " + initial_r + " * 10^" + power_r + " m")
            print("===============================================================")
            r = float(initial_r) * 10 ** float(power_r)

            v = (charge * b_field * r) / (mass)
            v_with_err = round(random.uniform(v * 0.9, v * 1.1), 2)

            self.play(Write(welcome))
            self.wait(3)
            self.play(FadeOut(welcome))

            f = Tex("Calculating velocity").set_color(BLACK).scale(1.5)
            f1 = MathTex(r"v = \frac{q * B * r}{m}").set_color(BLACK).move_to(2 * UP)
            f2 = Tex("The experimental value = " + str(v_with_err) + " m/s").set_color(BLACK)

            self.play(Write(f))
            self.wait(3)
            self.play(ReplacementTransform(f, f1))
            self.wait(2)
            self.play(Write(f2))

        elif choice == "2":
            initial_v, power_v = input(
                "Please enter velocity in the following format\nM P where v= M*10^P m/s\n"
            ).split(" ")
            print("===============================================================")
            print("V = " + initial_v + " * 10^" + power_v + " m")
            print("===============================================================")
            v = float(initial_v) * 10 ** float(power_v)

            r = (mass * v) / (charge * b_field)
            r_with_err = random.uniform(r * 0.9, r * 1.1)

            self.play(Write(welcome))
            self.wait(3)
            self.play(FadeOut(welcome))

            f = Tex("Calculating radius").set_color(BLACK).scale(1.5)
            f1 = MathTex(r"r = \frac{m * v}{q * B}").set_color(BLACK).move_to(2 * UP)
            f2 = Tex("The experimental value = " + str(r_with_err) + " m").set_color(BLACK)

            self.play(Write(f))
            self.wait(3)
            self.play(ReplacementTransform(f, f1))
            self.wait(2)
            self.play(Write(f2))

        else:
            print("Invalid choice")


class ExperimentEnergy(Scene):
    config.background_color = YELLOW_C

    def construct(self):
        name = input("Enter your name\n")
        print("===============================================================")
        initial_mass, power_mass = input(
            "Please enter mass of the particle in the following format\nM P where mass = M*10^P Kg\n"
        ).split(" ")
        print("===============================================================")
        mass = float(initial_mass) * 10 ** float(power_mass)
        print("m = " + initial_mass + " * 10^" + power_mass)
        print("===============================================================")
        initial_charge, power_charge = input(
            "Please enter charge of the particle in the following format\nM P where charge = M*10^P C\n"
        ).split(" ")
        print("===============================================================")
        print("q = " + initial_charge + " * 10^" + power_charge)
        print("===============================================================")
        charge = float(initial_charge) * 10 ** float(power_charge)
        initial_b, power_b = input(
            "Please enter Magnetic Field in the following format\nM P where B = M*10^P T\n"
        ).split(" ")
        print("===============================================================")
        print("B = " + initial_b + " * 10^" + power_b)
        print("===============================================================")
        b_field = float(initial_b) * 10 ** float(power_b)
        initial_r, power_r = input(
            "Please enter radius in the following format\nM P where r = M*10^P m\n"
        ).split(" ")
        print("===============================================================")
        print("R = " + initial_r + " * 10^" + power_r + " m")
        print("===============================================================")
        r = float(initial_r) * 10 ** float(power_r)

        welcome = Tex(
            r"Welcome " + name + r"!\\Let us begin with some hands-on experiments"
        ).set_color(BLACK)

        energy = ((charge * b_field * r) ** 2) / (2 * mass)
        energy_with_err = random.uniform(energy * 0.9, energy * 1.1)

        self.play(Write(welcome))
        self.wait(3)
        self.play(FadeOut(welcome))

        f = Tex("Calculating Energy").set_color(BLACK).scale(1.5)
        f1 = MathTex(r"E = \frac{(q * B * r)^{2}}{2 * m}").set_color(BLACK).move_to(2 * UP)
        f2 = Tex("The experimental value = " + str(energy_with_err) + " J").set_color(BLACK)

        self.play(Write(f))
        self.wait(3)
        self.play(ReplacementTransform(f, f1))
        self.wait(2)
        self.play(Write(f2))



# class FinalScene(Scene):
#     def construct(self):

#         myTemplate = TexTemplate()
#         myTemplate.add_to_preamble(r"\usepackage{circuitikz}")
#         myTemplate.add_to_preamble(r"\usepackage{tikz}")
#         myTemplate.add_to_preamble(r"\usepackage{siunitx}")

#         Dash = DashedLine([0,-3,0],[0,3,0])
#         Text1 = Text("Brightness")
#         Text2 = Text("Battery Life")

#         LED = Tex(r"""
#             \begin{circuitikz}[american]
#             \draw
#             (0,3) to[leD] (0,0)
#             ;
#             \end{circuitikz}
#             """,stroke_width=2,fill_opacity=0,tex_template = myTemplate)

#         V = Tex(r"""
#             \begin{circuitikz}[american]
#             \draw
#             (0,3) to[V] (0,0)
#             ;
#             \end{circuitikz}
#             """,stroke_width=2,fill_opacity=0,tex_template = myTemplate)

#         Bat = Tex(r"""
#             \begin{circuitikz}
#             \draw
#             (0,3) to[battery1] (0,0)
#             ;
#             \end{circuitikz}
#             """,stroke_width=2,fill_opacity=0,tex_template = myTemplate)
#         LED_Light = Circle(radius=1.3).move_to(np.array([2.8,0,0]))
#         LED_Light.set_fill(RED, opacity=0.5)
#         self.play(Create(Dash))
#         self.wait(1)
#         self.play(Write(Text1.move_to([3,3,0])),Write(Text2.move_to([-3,3,0])),Create(LED.move_to([3,0,0])),Create(V.move_to([-3,0,0])))
#         self.play(GrowFromCenter(LED_Light))
#         self.wait(3)
#         self.play(Transform(V,Bat.move_to([-3,0,0])))
#         self.wait(2)

# class Example(Scene):
#     def construct(self):
#         # g = NumberPlane()
#         # self.add(g)
#         tex_template_1 = TexTemplate()
#         tex_template_1.add_to_preamble(r"\usepackage{circuitikz}")
#         tex_template_1.add_to_preamble(r"\usepackage{tikz}")
#         circuit_1 = Tex(r"""
#                         \begin{circuitikz}[american voltages]
#                         \draw
#                         (0,0) to [short, *-] (6,0)
#                         to [V, l_=$\mathrm{j}{\omega}_m \underline{\psi}^s_R$] (6,2)
#                         to [R, l_=$R_R$] (6,4)
#                         to [short, i_=$\underline{i}^s_R$] (5,4)
#                         (0,0) to [open,v^>=$\underline{u}^s_s$] (0,4)
#                         to [short, *- ,i=$\underline{i}^s_s$] (1,4)
#                         to [R, l=$R_s$] (3,4)
#                         to [L, l=$L_{\sigma}$] (5,4)
#                         to [short, i_=$\underline{i}^s_M$] (5,3)
#                         to [L, l_=$L_M$] (5,0);
#                         \end{circuitikz}
#                         """, stroke_width = 2, fill_opacity = 0, tex_template = tex_template_1)
#         self.play(Write(circuit_1))
#         self.wait()
